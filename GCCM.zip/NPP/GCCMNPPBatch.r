setwd("/public/home/zhudh/RCode/GCCM")


library(parallel)
library(foreach)
library(doParallel)

source("basic.r")
source("GCCMParal.r")

load("npp.RData")


xNames<-c("pre10km","tem10km1") #""

yName<-"NPP"


yMatrix<-nppImage



lib_sizes<-seq(20,300,20)
E<-3
lib<-NULL

imageSize<-dim(yMatrix)
totalRow<-imageSize[1]
totalCol<-imageSize[2]
predRows<-seq(10,totalRow,10)
predCols<-seq(10,totalCol,10)

pred<-merge(predRows,predCols)

#plot(yImage)
coodsX<-seq(1,totalRow)
coodsY<-seq(1,totalCol)

coords<-merge(coodsX,coodsY)

colnames(coords)<-c("coordX","coodY")

y<-as.vector(yMatrix)

lmModel<-lm(y ~ coordX+coodY, cbind(y,coords))
prediction<-predict(lmModel,coords)
y<-y-prediction
yMatrixM<-matrix(y,nrow = totalRow, ncol = totalCol)

for(c in seq(1:length(climateImages)))
{
  
  xMatrix<- climateImages[[c]]
  
  x<-as.vector(xMatrix)
  
  lmModel<-lm(x ~ coordX+coodY, cbind(x,coords))
  prediction<-predict(lmModel,coords)
  x<-x-prediction
  xMatrixM<-matrix(x,nrow = totalRow, ncol = totalCol)
  
  
  startTime<-Sys.time()
  
  if(c==2)
  {
    	E=5
  }
  
  x_xmap_y <- GCCM(xMatrixM, yMatrixM, lib_sizes, lib, pred, E,cores=32) #
  y_xmap_x <- GCCM(yMatrixM, xMatrixM, lib_sizes, lib, pred, E,cores=32) #
  
  endTime<-Sys.time()
  
  print(difftime(endTime,startTime, units ="mins"))
  
  x_xmap_y$L <- as.factor(x_xmap_y$L)
  x_xmap_y_means <- do.call(rbind, lapply(split(x_xmap_y, x_xmap_y$L), function(x){max(0, mean(x$rho,na.rm=TRUE))}))
  
  y_xmap_x$L <- as.factor(y_xmap_x$L)
  y_xmap_x_means <- do.call(rbind, lapply(split(y_xmap_x, y_xmap_x$L), function(x){max(0, mean(x$rho,na.rm=TRUE))}))
  
 
  
  predIndices<-locate(pred[,1],pred[,2],totalRow,totalCol)
  yPred<- as.array(t(yMatrix))
  predicted<-na.omit(yPred[predIndices])
  
  x_xmap_y_Sig<- significance(x_xmap_y_means,length(predicted))
  y_xmap_x_Sig<- significance(y_xmap_x_means,length(predicted))
  

  x_xmap_y_interval<- confidence(x_xmap_y_means,length(predicted))
  colnames(x_xmap_y_interval)<-c("x_xmap_y_upper","x_xmap_y_lower")
  
  y_xmap_x_interval<- confidence(y_xmap_x_means,length(predicted))
  colnames(y_xmap_x_interval)<-c("y_xmap_x_upper","y_xmap_x_lower")
    
  results<-data.frame(lib_sizes,x_xmap_y_means,y_xmap_x_means,x_xmap_y_Sig,y_xmap_x_Sig,x_xmap_y_interval,y_xmap_x_interval)
  
  write.csv(results,file=paste("results/NPP/",xName,"_",yName,"_Pral.csv",sep=""))
  
  par(mfrow=c(1,1))
  par(mar=c(5, 4, 4, 2) + 0.1)
  
  jpeg(filename = paste("results/NPP/",xName,"_",yName,"_Pral.jpg",sep = ""),width = 600, height = 400)
  
  plot(lib_sizes, x_xmap_y_means, type = "l", col = "royalblue", lwd = 2,
       xlim = c(min(lib_sizes), max(lib_sizes)), ylim = c(0.0, 1), xlab = "L", ylab = expression(rho))
  lines(lib_sizes, y_xmap_x_means, col = "red3", lwd = 2)
  legend(min(lib_sizes), 1, legend = c("x xmap y", "y xmap x"), 
         xjust = 0, yjust = 1, lty = 1, lwd = 2, col = c("royalblue", "red3"))
  
  dev.off()
  
}











