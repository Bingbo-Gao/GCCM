setwd("E:\\Study\\R\\spatial-causality\\codes&data\\polygon")


library(parallel)
library(foreach)
library(doParallel)

source("GCCM4Lattice.r")
source("basic.r")



load("popShp.RData")



lib_sizes<-seq(10,2800,100)
E<-3

n <- NROW(columbus)
lib <- c(1, n)
pred <- c(1, n)




xNames<-c("DEM", 	"Tem",	"Pre",	"slop")

yName<-"popDensity"

columbus<-as.data.frame(columbus)

y<-columbus[,yName] 

lmModel<-lm(as.formula(paste(yName,"~x_1+y_1",sep = "")),columbus )
prediction<-predict(lmModel)
y<-y-prediction

coords<-columbus[,c("x_1","y_1")]

for(xName in xNames)
  
{
  x<-columbus[,xName] 
  
  lmModel2<-lm(as.formula(paste(xName,"~x_1+y_1",sep = "")),columbus )
  prediction<-predict(lmModel2,coords)
  x<-x-prediction
  
  #lmModel<-lm(y ~ x)
  
  #prediction<-predict(lmModel)
  
  #y<-y-prediction
  
  startTime<-Sys.time()
  
  
  embedings<-generateEmbedings(neighborMatrix,x,E)
  x_xmap_y <- GCCMLattice(embedings, y, lib_sizes, lib, pred, E,cores=8)
  
  
  embedings<-generateEmbedings(neighborMatrix,y,E)
  y_xmap_x <- GCCMLattice(embedings, x, lib_sizes, lib, pred, E,cores=8)
  
  
  endTime<-Sys.time()
  
  print(difftime(endTime,startTime, units ="mins"))
  
  x_xmap_y$L <- as.factor(x_xmap_y$L)
  x_xmap_y_means <- do.call(rbind, lapply(split(x_xmap_y, x_xmap_y$L), function(x){max(0, mean(x$rho,na.rm=TRUE))}))
  
  
  y_xmap_x$L <- as.factor(y_xmap_x$L)
  y_xmap_x_means <- do.call(rbind, lapply(split(y_xmap_x, y_xmap_x$L), function(x){max(0, mean(x$rho,na.rm=TRUE))}))
  
  
  x_xmap_y_Sig<- significance(x_xmap_y_means,pred[2])
  y_xmap_x_Sig<- significance(y_xmap_x_means,pred[2])
  
  x_xmap_y_interval<- confidence(x_xmap_y_means,pred[2])
  colnames(x_xmap_y_interval)<-c("x_xmap_y_upper","x_xmap_y_lower")
  
  y_xmap_x_interval<- confidence(y_xmap_x_means,pred[2])
  colnames(y_xmap_x_interval)<-c("y_xmap_x_upper","y_xmap_x_lower")
  
  
  results<-data.frame(lib_sizes,x_xmap_y_means,y_xmap_x_means,x_xmap_y_Sig,y_xmap_x_Sig,x_xmap_y_interval,y_xmap_x_interval)
  
  
  results<-data.frame(lib_sizes,x_xmap_y_means,y_xmap_x_means)
  
  write.csv(results,file=paste("results/Pop/",xName,"_",yName,"LatLon.csv",sep=""))
  
  par(mfrow=c(1,1))
  par(mar=c(5, 4, 4, 2) + 0.1)
  
  
  
  jpeg(filename = paste("results/Pop/",xName,"_",yName,"LatLon.jpg",sep = ""),width = 600, height = 400)
  
  plot(lib_sizes, x_xmap_y_means, type = "l", col = "royalblue", lwd = 2, 
       xlim = c(min(lib_sizes), max(lib_sizes)), ylim = c(0.0, 1), xlab = "L", ylab = expression(rho))
  lines(lib_sizes, y_xmap_x_means, col = "red3", lwd = 2)
  legend(min(lib_sizes), 1, legend = c("x xmap y", "y xmap x"), 
         xjust = 0, yjust = 1, lty = 1, lwd = 2, col = c("royalblue", "red3"))
  
  dev.off()
}








