In the new version of GCCM_updated2, the following updates have been introduced when the user's original data is in raster format (tif):

（1）Null Value Handling: Added measures for handling null values, which can be set using the validRatio parameter.

（2）Anisotropy Support: Introduced anisotropy functionality, which can be set using the dir parameter.

（3）Window Sliding: Added a window skipping feature, which can be set using the winStepRatio parameter.



在GCCM_updated2的新版本中，当用户原始数据为栅格时，有以下功能的更新：

（1）增加了空值处理措施，可以通过validRatio参数进行设置；

（2）增加了各项异性功能，可以通过dir参数进行设置；

（3）增加了窗口跳过功能，可以通过winStepRatio参数进行设置。