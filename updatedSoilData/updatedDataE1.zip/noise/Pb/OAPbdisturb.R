setwd("/work/home/ac1opnizd4/GCCM/Runorgicode")

library(parallel)
library(foreach)
library(doParallel)


source("basic.r")
source("GCCMParalalldir.r")
load("CuCdMgPbEnvi.RData")



HMs<-c("Cu","Cd","Mg","Pb") 
Envs<-c("Nightlight","factorydensity")

lib_sizes<-seq(10,120,20)
lib<-NULL


E=3

yImage<- HMImages[[4]]
yName<-HMs[4]
      
yMatrix<-as.matrix(yImage)
imageSize<-dim(yMatrix)
totalRow<-imageSize[1]
totalCol<-imageSize[2]

    
predRows<-seq(5,totalRow,5)
predCols<-seq(5,totalCol,5)
pred<-merge(predRows,predCols)

    for(e in 1:length(Envs))
    {
      xImage<-EnviImages[[e]]
      
      xName<-Envs[e]
      
      xMatrix<-as.matrix(xImage)
      # test<-1
      # write.csv(test,file=paste("3Pb/",yName,xName,"test111111",".csv",sep = ""))  
      

    
    disRange<-c(0.1,0.3,0.6,0.9)
    
    
    for(d in disRange){
      y<-as.vector(yMatrix)
      disturb<-runif(length(y))
      y<-y+disturb*d*y
      yMatrixM<-matrix(y,nrow = totalRow, ncol = totalCol)
      ############################
      save(disturb,y,yMatrixM,file=paste("3Pb/",xName,"_",yName,"_dis",d,"simulateddata","_.RData",sep = ""))
      
      
      
      startTime<-Sys.time()
      
      x_xmap_y <- GCCM(xMatrix, yMatrixM, lib_sizes, lib, pred, E, tau = 1, b = E+1, cores=30)   #predict y with x
      y_xmap_x <- GCCM(yMatrixM, xMatrix, lib_sizes, lib, pred, E, tau = 1, b = E+1, cores=30)    #predict x with y
      
      # x_xmap_y <- GCCM(xMatrix, yMatrixM, lib_sizes, lib, pred, E,tau = 1,b=E+a,winStepRatio = 0,cores=12,dir=0)
      # y_xmap_x <- GCCM(yMatrixM, xMatrix, lib_sizes, lib, pred, E,tau = 1,b=E+a,winStepRatio = 0,cores=12,dir=0)
      # 
      
      x_xmap_y$L <- as.factor(x_xmap_y$L)
      x_xmap_y_means <- do.call(rbind, lapply(split(x_xmap_y, x_xmap_y$L), function(x){max(0, mean(x$rho,na.rm=TRUE))}))
      
      
      y_xmap_x$L <- as.factor(y_xmap_x$L)
      y_xmap_x_means <- do.call(rbind, lapply(split(y_xmap_x, y_xmap_x$L), function(x){max(0, mean(x$rho,na.rm=TRUE))}))

      x_xmap_y_Sig<- significance(x_xmap_y_means,nrow(pred))
      y_xmap_x_Sig<- significance(y_xmap_x_means,nrow(pred))
      
      x_xmap_y_interval<- confidence(x_xmap_y_means,nrow(pred))
      colnames(x_xmap_y_interval)<-c("x_xmap_y_upper","x_xmap_y_lower")
      
      y_xmap_x_interval<- confidence(y_xmap_x_means,nrow(pred))
      colnames(y_xmap_x_interval)<-c("y_xmap_x_upper","y_xmap_x_lower")
      
      results_Cu<-data.frame(lib_sizes,x_xmap_y_means,y_xmap_x_means,x_xmap_y_Sig,y_xmap_x_Sig,x_xmap_y_interval,y_xmap_x_interval)
      ##############################################
      if (length(x_xmap_y_means) == length(y_xmap_x_means)){
        write.csv(results_Cu, file=paste("3Pb/",xName,"_",yName,"_disz",d,"_.csv",sep = ""))
      }else{
        save(x_xmap_y_means,y_xmap_x_means,file = paste("3Pb/",xName,"_",yName,"_disz",d,"_.RData",sep = ""))
      }
      par(mfrow=c(1,1))
      par(mar=c(5, 4, 4, 2) + 0.1)
      
      ##############################################
      jpeg(filename = paste("3Pb/",yName,xName,"_disz1_",d,".jpg",sep = ""),width = 600, height = 400)
      
      plot(lib_sizes, x_xmap_y_means, type = "l", col = "royalblue", lwd = 2, 
           xlim = c(min(lib_sizes), max(lib_sizes)), ylim = c(0.0, 1), xlab = "L", ylab = expression(rho))
      lines(lib_sizes, y_xmap_x_means, col = "red3", lwd = 2)
      legend(min(lib_sizes), 1, legend = c(paste(xName,"xmap",yName,sep=" "), paste(yName,"xmap",xName,sep=" ")), 
             xjust = 0, yjust = 1, lty = 1, lwd = 2, col = c("royalblue", "red3"))
      
      dev.off()
      
      endTime<-Sys.time()
      
      print(difftime(endTime,startTime, units ="mins"))
      
      save.image(file=paste("3Pb/",yName,xName,"_disz1_",d,"Alloperationaldata",".RData",sep = ""))
    }
    
    }   
    # }
        
    
    
    